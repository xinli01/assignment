#!/usr/bin/env python3
import logging

from app.FolderStore import FolderStore

CREATE_COMMAND_PREFIX = 'CREATE'
LIST_COMMAND_PREFIX = 'LIST'
MOVE_COMMAND_PREFIX = 'MOVE'
DELETE_COMMAND_PREFIX = 'DELETE'
HELP_COMMAND_PREFIX = 'HELP'
EXIT_COMMAND_PREFIX = 'EXIT'

logger = logging.getLogger(__name__)

def main():
    print('Welcome to folder demo')
    print('type `HELP` for a list of available commands')
    print('type `EXIT` to end the program')

    store = FolderStore()

    while True:
        command = input().strip()
        uppercased_command = command.upper()

        try :
            if uppercased_command.startswith(CREATE_COMMAND_PREFIX):
                store.create_folder(command)
            elif uppercased_command.startswith(MOVE_COMMAND_PREFIX):
                store.move_folder(command)
            elif uppercased_command.startswith(DELETE_COMMAND_PREFIX):
                store.delete_folder(command)
            elif uppercased_command.startswith(LIST_COMMAND_PREFIX):
                store.list_folder()
            elif uppercased_command.startswith(HELP_COMMAND_PREFIX):
                print_help()
            elif uppercased_command.startswith(EXIT_COMMAND_PREFIX):
                exit(0)
            else:
                print('unrecognized command')
        except ValueError as e:
            print(e)

def print_help():
    print('CREATE: create a folder. Syntax: `CREATE {folder path}`, eg: `CREATE fruits/apples`')
    print('DELETE: delete a folder. Syntax: `DELETE {folder path}`, eg: `DELETE fruits/apples`')
    print('LIST: list all folders. Syntax: `LIST`, eg: `LIST`')
    print('MOVE: move a folder(and its subfolders) to a new location. Syntax: `MOVE {current folder path} {destination folder path}`, eg: `MOVE grains/squash vegetables`')
    print('EXIT: exit the program. Syntax: `EXIT`')
    print('HELP: list all the commands. Syntax: `HELP`')


if __name__ == "__main__":
    main()