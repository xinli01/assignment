import logging

from app.FolderNode import FolderNode

logger = logging.getLogger(__name__)

class FolderStore:

    def __init__(self):
        self.root = FolderNode('.')
        self.folder_names = set()

    def create_folder(self, command):
        """
        Steps:
        1. parse the command and get the path
        2. find the parent folder in the path
        3. check in the store, the parent folder exists,
        4. check in the store, the parent folder doesn't have same name folder
        5. create a folder obj, insert into the val of the parent key
        syntax eg: `CREATE fruits/apples`
        """
        splits = command.split()
        path = splits[1]
        folder, not_found_folder_name = self.find_folder(path)
        if folder:
            raise ValueError(f'Cannot create {path} - folder already exists')

        self.create_folder_path(path)

    def move_folder(self, command):
        """
        steps:
        1. parse the folder to get the source and dest parent
        2. check if the source exist
        3. check if the dest parent doesn't have same name source
        4. move the source to the dest
        syntax: `MOVE grains/squash vegetables`
        """
        splits = command.split()
        source_path = splits[1]
        destination_path = splits[2]

        source_folder, not_found_folder_name = self.find_folder(source_path)
        if not source_folder:
            raise ValueError(f'Cannot move {source_path} - {not_found_folder_name} does not exist')

        destination_folder, not_found_folder_name = self.find_folder(destination_path)
        if not destination_folder:
            raise ValueError(f'Cannot move {source_path} to {destination_path} - {not_found_folder_name} does not exist')

        source_parent_folder = self.find_parent_folder(source_path)

        source_parent_folder.sub_nodes.pop(source_folder.folder_name)
        destination_folder.add_existing_subfolder(source_folder)

        return

    def delete_folder(self, command):
        """
        Steps:
        1. parse the dest folder
        2. find the parent folder
        3. check if dest folder exist
        4. delete
        """
        splits = command.split()

        folder_path = splits[1]
        folders = folder_path.split('/')

        parent = None
        current = self.root

        target_folder, not_found_folder_name = self.find_folder(folder_path)
        if not target_folder:
            raise ValueError(f'Cannot delete {folder_path} - {not_found_folder_name} does not exist')

        for fn in folders:
            if fn in current.sub_nodes.keys():
                next_folder = current.sub_nodes.get(fn)
                parent = current
                current = next_folder

        parent.sub_nodes.pop(current.folder_name)

        return

    def list_folder(self):
        """
        #  start from root
        # for each folder under, order by alph,
        # do dfs recursively with level to calculate indentation
        """
        self.root.level_print(-1)

    # below are helper functions
    def create_folder_path(self, folder_path):

        current_folder = self.root
        paths = folder_path.split('/')

        for fn in paths:
            if fn not in current_folder.sub_nodes.keys():

                current_folder.create_new_subfolder(fn)
            current_folder = current_folder.sub_nodes.get(fn)

        return

    def find_folder(self, folder_path):

        paths = folder_path.split('/')
        current = self.root

        for fn in paths:
            if fn in current.sub_nodes.keys():
                current = current.sub_nodes[fn]
            else:
                return None, fn

        return current, None

    def find_parent_folder(self, source_path):
        splits = source_path.split('/')
        if len(splits) <= 1:
            return self.root
        else:
            return self.find_folder('/'.join(splits[:-1]))[0]










