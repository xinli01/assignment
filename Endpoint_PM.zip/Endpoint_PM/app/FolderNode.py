import logging

logger = logging.getLogger(__name__)

class FolderNode:

    def __init__(self, name):
        if not name or len(name) < 1:
            raise ValueError('folder name must not be empty')

        self.folder_name = name
        self.sub_nodes = {} # key is folder name, value is node

    def add_existing_subfolder(self, folder_node):
        if folder_node.folder_name in self.sub_nodes.keys():
            raise ValueError('folder with same name already exists')

        self.sub_nodes[folder_node.folder_name] = folder_node

    def create_new_subfolder(self, folder_name):
        if folder_name in self.sub_nodes.keys():
            raise ValueError('folder with same name already exists')

        self.sub_nodes[folder_name] = FolderNode(folder_name)

    def remove_subfolder(self, folder_name):
        if folder_name not in self.sub_nodes.keys():
            raise ValueError('folder not exist')

        return self.sub_nodes.pop(folder_name)

    def level_print(self, level):
        spaces = ' ' * level

        if level >= 0:
            print(spaces + self.folder_name)

        subfolder_names = list(self.sub_nodes.keys())
        subfolder_names.sort()
        for sn in subfolder_names:
            self.sub_nodes.get(sn).level_print(level + 1)






