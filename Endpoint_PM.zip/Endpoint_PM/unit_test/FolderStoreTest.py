import unittest

from app.FolderStore import FolderStore


class MyTestCase(unittest.TestCase):
    def test_create_folder(self):

        store = FolderStore()
        store.create_folder('CREATE fruits/apples/fuji')
        store.create_folder('CREATE fruits/apples/gala')

        store.list_folder()

        apple_folder, _ = store.find_folder('fruits/apples')
        self.assertEqual(2, len(apple_folder.sub_nodes))

    def test_create_folder_duplicate_exception(self):
        store = FolderStore()
        store.create_folder('CREATE fruits/apples/fuji')

        with self.assertRaises(ValueError) as context:
            store.create_folder('CREATE fruits/apples/fuji')
        self.assertEqual('Cannot create fruits/apples/fuji - folder already exists', str(context.exception))

    def test_move_folder(self):
        store = FolderStore()
        store.create_folder('CREATE fruits/apples/fuji')
        store.create_folder('CREATE fruits/apples/sunkist')
        store.create_folder('CREATE fruits/oranges')

        store.move_folder('MOVE fruits/apples/sunkist fruits/oranges')
        store.list_folder()
        oranges_folder, _ = store.find_folder('fruits/oranges')
        self.assertEqual(1, len(oranges_folder.sub_nodes))

    def test_move_folder_root_level(self):
        store = FolderStore()
        store.create_folder('CREATE fruits/apples/fuji')
        store.create_folder('CREATE fruits/apples/gala')
        store.create_folder('CREATE food')

        store.move_folder('MOVE fruits food')
        # store.list_folder()
        self.assertEqual(1, len(store.root.sub_nodes))

    def test_delete_folder(self):
        store = FolderStore()
        store.create_folder('CREATE fruits/apples/fuji')
        store.create_folder('CREATE fruits/apples/gala')
        store.delete_folder('DELETE fruits/apples/gala')
        store.delete_folder('DELETE fruits/apples')
        store.delete_folder('DELETE fruits')
        store.list_folder()

if __name__ == '__main__':
    unittest.main()
