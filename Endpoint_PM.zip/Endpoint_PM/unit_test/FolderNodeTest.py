import unittest

from app.FolderNode import FolderNode


class MyTestCase(unittest.TestCase):
    def test_ctor(self):
        node = FolderNode('test')
        self.assertEqual('test', node.folder_name)

    def test_ctor_invalid_name_exception(self):
        with self.assertRaises(ValueError) as context:
            FolderNode('')
        self.assertEqual(str(context.exception), 'folder name must not be empty')

    def test_add_existing_subfolder(self):
        node1 = FolderNode('parent')
        node2 = FolderNode('sub')
        node1.add_existing_subfolder(node2)
        self.assertEqual(1, len(node1.sub_nodes))
        self.assertEqual('sub', list(node1.sub_nodes.keys())[0])

    def test_add_existing_subfolder_duplicate_exception(self):
        node1 = FolderNode('parent')
        node2 = FolderNode('sub')
        node1.add_existing_subfolder(node2)
        with self.assertRaises(ValueError) as context:
            node1.add_existing_subfolder(node2)
        self.assertEqual(str(context.exception), 'folder with same name already exists')

    def test_create_new_subfolder(self):
        node1 = FolderNode('parent')
        node1.create_new_subfolder('sub')
        self.assertEqual(1, len(node1.sub_nodes))
        self.assertEqual('sub', list(node1.sub_nodes.keys())[0])

    def test_create_new_subfolder_duplicate_name_exception(self):
        node1 = FolderNode('parent')
        node1.create_new_subfolder('sub')
        with self.assertRaises(ValueError) as context:
            node1.create_new_subfolder('sub')
        self.assertEqual(str(context.exception), 'folder with same name already exists')

    def test_remove_subfolder(self):
        node1 = FolderNode('parent')
        node1.create_new_subfolder('sub')
        node1.remove_subfolder('sub')
        self.assertEqual(0, len(node1.sub_nodes))

    def test_remove_subfolder_nonexist_exception(self):
        node1 = FolderNode('parent')
        node1.create_new_subfolder('sub')

        with self.assertRaises(ValueError) as context:
            node1.remove_subfolder('sub1')
        self.assertEqual(str(context.exception), 'folder not exist')

    def test_level_print(self):
        root_node = self.setup_folders()
        root_node.level_print(-1)

    def setup_folders(self):
        node_fuji = FolderNode('fuji')
        node_apples = FolderNode('apples')
        node_apples.add_existing_subfolder(node_fuji)
        node_fruits = FolderNode('fruits')
        node_fruits.add_existing_subfolder(node_apples)

        node_squash = FolderNode('squash')
        node_vegetables = FolderNode('vegetables')
        node_vegetables.add_existing_subfolder(node_squash)

        node_grain = FolderNode('grain')
        node_food = FolderNode('food')
        node_food.add_existing_subfolder(node_fruits)
        node_food.add_existing_subfolder(node_vegetables)
        node_food.add_existing_subfolder(node_grain)

        node_root = FolderNode('.')
        node_root.add_existing_subfolder(node_food)

        return node_root

if __name__ == '__main__':
    unittest.main()
