## Readme

### Code structure
The project is written in python.
the application code is in the app folder, 
there are 3 files: 
1. **`__main__.py`**:
   The main entry point of the application. It contains the command-line interface (CLI) logic and serves 
   as the starting point for running the app.
2. **`FolderStore.py`**: 
   The core component of the application, responsible for managing the folder tree structure. 
3. **`FolderNode.py`**: A class that represents an individual folder within the folder tree structure.

### Unit test
The `unit_test` folder includes unit tests for the `FolderStore` and `FolderNode` components.

### How to run
![run on terminal](start.png)

To execute the application from the terminal, follow these steps:
1. Ensure that **Python 3** is installed on your system and that the Python 3 executable is included in your system's `$PATH`.
2. Open a terminal and navigate to the `Endpoint_PM` folder.
3. Run the following command to start the application: `python3 -m app`
4. To exit the application, type `EXIT`

### Design

#### Create
The `CREATE` operation supports adding multiple folders in a single command. 
For example:
- If the hierarchy initially contains only `fruits`, executing the command `CREATE fruits\apple\fuji` will create all the necessary directories (`apple` and `fuji`) under `fruits`.

#### List
The `LIST` command uses a recursive depth-first search (DFS) algorithm to traverse the folder hierarchy. 
It uses a `level` variable to calculate the appropriate indentation for each folder. Key details include:
- The initial `level` is set to `-1` to avoid printing the root folder.
- Subfolders at the same level are printed in alphabetical order.
This approach ensures a clear, organized, and hierarchical representation of the folder structure.












